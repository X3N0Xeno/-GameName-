extends Sprite2D

@export var puzzle_id: String = ""
var dragging: bool = false
var cluster: Array = []   # group of fragments moving together
var pending_snap: Dictionary = {}  # store snap info until button_up

static var counter = 0;

# Define valid connections (fragment:side → fragment:side)
const VALID_CONNECTIONS = {
	"Fragment 1:Right": "Fragment 2:Left",
	"Fragment 1:Down": "Fragment 3:Top",
	"Fragment 2:Left": "Fragment 1:Right",
	"Fragment 2:Down": "Fragment 4:Top",
	"Fragment 3:Top": "Fragment 1:Down",
	"Fragment 3:Down": "Fragment 5:Top",
	"Fragment 3:Right": "Fragment 4:Left",
	"Fragment 4:Top": "Fragment 2:Down",
	"Fragment 4:Down": "Fragment 6:Top",
	"Fragment 4:Left": "Fragment 3:Right",
	"Fragment 5:Right": "Fragment 6:Left",
	"Fragment 5:Top": "Fragment 3:Down",
	"Fragment 6:Left": "Fragment 5:Right",
	"Fragment 6:Top": "Fragment 4:Down"
}

func _ready() -> void:
	cluster = [self]

	# --- Final resting position ---
	var camera := get_viewport().get_camera_2d()
	var cam_offset := Vector2.ZERO
	if camera:
		cam_offset = camera.global_position

	var spawn_top_left := cam_offset + Vector2(-250, -225)
	var spawn_size := Vector2(450, 450)

	var final_pos := Vector2(
		randf_range(spawn_top_left.x, spawn_top_left.x + spawn_size.x),
		randf_range(spawn_top_left.y, spawn_top_left.y + spawn_size.y)
	)

	# --- Place fragment at final position immediately ---
	global_position = final_pos

	# --- Start with big scale ---
	scale = Vector2(2, 2)

	# Tween only scale (shrinking in place)
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector2(1, 1), randf_range(0.8, 1.2)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	# Connect area signals for snapping
	for side in ["Right", "Left", "Top", "Down"]:
		if has_node(side):
			var area: Area2D = get_node(side)
			area.area_entered.connect(_on_area_entered.bind(side))




func _process(_delta: float) -> void:
	if dragging:
		var mouse_pos = get_global_mouse_position()
		var delta = mouse_pos - global_position
		for piece in cluster:
			piece.global_position += delta

func _on_button_button_down() -> void:
	dragging = true
	pending_snap.clear()

func _on_button_button_up() -> void:
	dragging = false
	if pending_snap.has("other_piece"):
		counter += 1
		var other_piece: Sprite2D = pending_snap["other_piece"]
		var my_side: String = pending_snap["my_side"]

		# calculate snap offset based on sprite size and side
		var my_half = texture.get_size() * 0.5 * scale
		var snap_offset := Vector2.ZERO

		match my_side:
			"Right": #change + to -
				snap_offset = Vector2(-(my_half.x *2),0)
			"Left":
				snap_offset = Vector2((my_half.x *2), 0)
			"Top":
				snap_offset = Vector2(0, (my_half.y *2))
			"Down":
				snap_offset = Vector2(0, -(my_half.y *2))

		var target_pos = other_piece.global_position + snap_offset
		var delta = target_pos - global_position

		for piece in cluster:
			piece.global_position += delta

		if other_piece.cluster != cluster:
			cluster = cluster + other_piece.cluster
			for piece in cluster:
				piece.cluster = cluster
	
	pending_snap.clear()
	print(counter)
	if counter == 5:
			game_over()

func _on_area_entered(other_area: Area2D, my_side: String) -> void:
	if not dragging:
		return

	var other_piece: Sprite2D = other_area.get_parent() as Sprite2D
	if other_piece == null or other_piece == self:
		return

	var my_key = name + ":" + my_side
	var other_key = other_piece.name + ":" + other_area.name

	if VALID_CONNECTIONS.has(my_key) and VALID_CONNECTIONS[my_key] == other_key:
		pending_snap = {
			"other_piece": other_piece,
			"my_side": my_side,
			"other_side": other_area.name
		}
		
func game_over() -> void:
	dragging = false

	# (Your existing code to disable buttons...)
	for piece in cluster:
		if piece.has_node("Button"):
			var btn = piece.get_node("Button")
			btn.disabled = true

	# (Your existing code to center the puzzle...)
	var cluster_center := Vector2.ZERO
	for piece in cluster:
		cluster_center += piece.global_position
	cluster_center /= cluster.size()
	var camera := get_viewport().get_camera_2d()
	var target_center := Vector2.ZERO
	if camera:
		target_center = camera.get_screen_center_position()
	else:
		target_center = get_viewport_rect().size * 0.5
	var shift := target_center - cluster_center
	var tween := create_tween()
	for piece in cluster:
		tween.tween_property(
			piece, "global_position",
			piece.global_position + shift, 
			0.567
		).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	# --- THIS IS THE NEW PART ---
	# Wait for the tween to finish
	await tween.finished

	# 1. Check if we've *already* completed this puzzle
	if not puzzle_id in PortalManager.completed_puzzles:
		# If not, add it to the permanent list
		PortalManager.completed_puzzles.append(puzzle_id)
		# Update the global count
		PortalManager.puzzles_completed_count = PortalManager.completed_puzzles.size()
		print("Puzzle ", puzzle_id, " COMPLETED! Total: ", PortalManager.puzzles_completed_count)

	# 2. Wait 2 seconds (for the player to see the solved puzzle)
	await get_tree().create_timer(2.0).timeout 

	# 3. Now, load the return scene from the PortalManager
	var return_scene = PortalManager.puzzle_return_scene_path
	if return_scene.is_empty():
		print("PUZZLE ERROR: No return scene set!")
		return

	get_tree().call_deferred("change_scene_to_file", return_scene)
	# --------------------------
